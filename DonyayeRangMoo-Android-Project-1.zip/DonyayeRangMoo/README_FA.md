# دنیای رنگ مو — پروژه اندروید

این پروژه نسخه وبِ موجود را داخل یک WebView اندروید اجرا می‌کند و تصاویر محصولات داخل فایل HTML جاسازی شده‌اند.

## ساخت APK در Android Studio
1. Android Studio را نصب کنید.
2. از گزینه **Open** پوشه `DonyayeRangMoo` را باز کنید.
3. اجازه دهید Gradle Sync کامل شود (برای دریافت Android Gradle Plugin و SDK اینترنت لازم است).
4. از منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** را انتخاب کنید.
5. فایل آزمایشی در `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

## ساخت نسخه امضاشده برای انتشار
در Android Studio از **Build > Generate Signed Bundle / APK** استفاده کنید و برای انتشار، اطلاعات امضای برنامه را امن نگه دارید. قبل از ارسال به کافه‌بازار، شرایط و قالب بسته مورد قبول بازار را بررسی کنید.

شناسه برنامه: `ir.rabrat.donyayerangmoo`
نام نمایشی: دنیای رنگ مو
نسخه: 1.0.0
