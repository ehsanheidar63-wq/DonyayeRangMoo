# دنیای رنگ مو

پروژهٔ اندروید WebView برای نمایش نسخهٔ وب در `app/src/main/assets/index.html`.

## ساخت خودکار APK

این مخزن شامل GitHub Actions است. پس از قرار دادن تمام محتویات این پوشه در ریشهٔ یک مخزن GitHub، به تب **Actions** بروید و workflow با نام **Build Donyaye Rang Moo APK** را اجرا کنید. پس از موفقیت، فایل APK در بخش **Artifacts** با نام `DonyayeRangMoo-APK` قابل دانلود است.

APK ساخته‌شده از این workflow نسخهٔ debug است و برای آزمایش روی گوشی است؛ برای انتشار نهایی در فروشگاه باید نسخهٔ release امضاشده و شرایط روز فروشگاه بررسی شود.
